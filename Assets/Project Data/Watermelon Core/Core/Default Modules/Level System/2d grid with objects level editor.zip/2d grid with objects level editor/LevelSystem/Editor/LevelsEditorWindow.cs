﻿#pragma warning disable 649, 168

using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;
using System.Text.RegularExpressions;

namespace Watermelon
{
    public class LevelsEditorWindow : LevelEditorBase
    {
        //temp variables or variables that used in different tabs
        private TabHandler tabHandler;
        private const string ELEMENTS_TAB_LABEL = "Field elements";
        private const string LEVELS_TAB_LABEL = "Levels";
        private const string TEXTURES_TAB_LABEL = "Textures";
        private LevelRepresentation selectedLevelRepresentation;
        private const string FIELD_ELEMENT_PROPERTY_NAME = "fieldElement";
        private const string TEXTURE_PROPERTY_NAME = "texture";
        private const string HORIZIONTAL_OFFSET_PROPERTY_NAME = "horizontalOffset";
        private const string VERTICAL_OFFSET_PROPERTY_NAME = "verticalOffset";
        private const string SIZE_PROPERTY_NAME = "size";
        private const string FIELD_ELEMENT_LABEL = "Field element:";
        private static Rect tempTextureRect;
        private Event currentEvent;
        private Rect textureRect;
        private SerializedProperty horizontalOffsetSerializedProperty;
        private SerializedProperty verticalOffsetSerializedProperty;
        private SerializedProperty sizeSerializedProperty;
        private SerializedProperty textureSerializedProperty;

        //level database
        private const string LEVELS_PROPERTY_NAME = "levels";
        private const string ENEMIES_PROPERTY_NAME = "enemies";
        private const string OBSTACLES_PROPERTY_NAME = "obstacles";
        private const string PLACEHOLDER_TEXTURE_PROPERTY_NAME = "placeholderTexture";
        private const string GREEN_TEXTURE_PROPERTY_NAME = "greenTexture";
        private const string RED_TEXTURE_PROPERTY_NAME = "redTexture";
        private const string ITEM_BACKGROUND_TEXTURE_PROPERTY_NAME = "itemBackgroundTexture";
        private SerializedProperty levelsSerializedProperty;
        private SerializedProperty obstaclesSerializedProperty;
        private SerializedProperty enemiesSerializedProperty;
        private SerializedProperty placeholderTextureProperty;
        private SerializedProperty greenTextureProperty;
        private SerializedProperty redTextureProperty;
        private SerializedProperty itemBackgroundTextureTextureProperty;
        private static Texture2D placeholderTexture;
        private Texture2D greenTexture;
        private Texture2D redTexture;
        private Texture2D itemBackgroundTexture;




        //Elements tab variables
        private const string ENEMY_FOLDER_NAME = "Enemy";
        private const string OBSTACLE_FOLDER_NAME = "Obstacle";
        private const string ASSET_SUFFIX = ".asset";
        private const string FILENAME_REGEX_PATTERN = "^[a-zA-Z0-9_ ]+$";
        private const string FILENAME_INCORRECT_ERROR = "Filename don`t match regex pattern: ";
        private const string FILE_ALREADY_EXIST_ERROR = "File with this name already exist.";
        private const string CREATE_OBJECT_LABEL = "Create new object";
        private const string NEW_OBJECT_LABEL = "New object filename";
        private const string OBSTACLES_LABEL = "Obstacles";
        private const string ENEMIES_LABEL = "Enemies";
        private const float START_OFFSET = 10;
        private const float LINE_WIDTH = 2f;
        private const int SPRITE_ELEMENT_SIZE = 24;
        private const string DELETE_LABEL = "Delete";
        private const string SOURSE_SCRIPT_PROPERTY_NAME = "m_Script";
        private const string ELEMENTS_TAB_INSTRUCTION = "You can open elements for editing by clicking on them.";
        private const string OBSTACLE_DEFAULT_NAME = "Obstacle_1x1";
        private const string ENEMY_DEFAULT_NAME = "Enemy 1x1";
        private Regex fileNameRegex;
        private static LevelItemType selectedType;
        private static Type texture2DType;

        private string ENEMY_FOLDER_PATH { get => LEVELS_DATABASE_FOLDER_PATH + PATH_SEPARATOR + ENEMY_FOLDER_NAME; }
        private string OBSTACLE_FOLDER_PATH { get => LEVELS_DATABASE_FOLDER_PATH + PATH_SEPARATOR + OBSTACLE_FOLDER_NAME; }

        //levels tab
        private const string ERROR = "Error";
        private const string OK = "OK";
        private const int SIDEBAR_WIDTH = 160;
        private const string PALETTE_CELL_SIZE = "paletteCellSize";
        private const string LEVEL_CELL_SIZE = "levelCellSize";
        private const string LINE_SEPARATOR = ".\n";
        private const string ELEMENT_SEPARATOR = ", ";
        private const string NULL_OBJECT = "null object";
        private const string DEFAULT_TEXTURES_MISSING = "Default textures missing: ";
        private const string TEXTURES_MISSING = " textures missing in: ";
        private int levelCellSize;
        private int paletteCellSize;
        private Rect groupRect;
        private float startPosX;
        private float startPosY;
        private float maxHeight;
        private LevelsHandler levelsHandler;
        private Vector2 firstRotatingPoint;
        private Vector2 secondRotatingPoint;
        private float levelGridPositionX;
        private float levelGridPositionY;
        private Vector2Int draggetItemUIGridPosition;
        private Vector2 rectPosition;
        private Vector2Int itemUIGridPosition;
        private Vector2 itemPosition;
        private Rect fullRect;
        private Rect texturePointRect;
        private Matrix4x4 matrixBackup;
        private Rect levelRect;
        private Vector2 levelScrolVector;
        private List<LevelElement> itemTypes;

        //drag
        private bool itemIsDragged;
        private int draggedItemLevelIndex;
        private int draggedItemCachedIndex;
        private int draggetItemAngle;
        private LevelItemType draggetItemType;
        private SourceType draggetItemSource;
        private bool draggetItemSnapActive;
        private bool draggetItemDropAcceptable;
        private List<Vector2Int> filledGridCells;
        private List<Vector2Int> draggetItemGridCells;


        protected override WindowConfiguration SetUpWindowConfiguration(WindowConfiguration.Builder builder)
        {
            return builder.SetWindowMinSize(new Vector2(600, 300)).Build();
        }

        protected override Type GetLevelsDatabaseType()
        {
            return typeof(LevelDatabase);
        }

        public override Type GetLevelType()
        {
            return typeof(Level);
        }

        protected override void ReadLevelDatabaseFields()
        {
            levelsSerializedProperty = levelsDatabaseSerializedObject.FindProperty(LEVELS_PROPERTY_NAME);
            obstaclesSerializedProperty = levelsDatabaseSerializedObject.FindProperty(OBSTACLES_PROPERTY_NAME);
            enemiesSerializedProperty = levelsDatabaseSerializedObject.FindProperty(ENEMIES_PROPERTY_NAME);


            //TextureProperties
            placeholderTextureProperty = levelsDatabaseSerializedObject.FindProperty(PLACEHOLDER_TEXTURE_PROPERTY_NAME);
            greenTextureProperty = levelsDatabaseSerializedObject.FindProperty(GREEN_TEXTURE_PROPERTY_NAME);
            redTextureProperty = levelsDatabaseSerializedObject.FindProperty(RED_TEXTURE_PROPERTY_NAME);
            itemBackgroundTextureTextureProperty = levelsDatabaseSerializedObject.FindProperty(ITEM_BACKGROUND_TEXTURE_PROPERTY_NAME);

            //Textures
            placeholderTexture = (Texture2D)placeholderTextureProperty.objectReferenceValue;
            greenTexture = (Texture2D)greenTextureProperty.objectReferenceValue;
            redTexture = (Texture2D)redTextureProperty.objectReferenceValue;
            itemBackgroundTexture = (Texture2D)itemBackgroundTextureTextureProperty.objectReferenceValue;
        }

        protected override void InitialiseVariables()
        {
            CreateFolderIfNotExist(ENEMY_FOLDER_PATH);
            CreateFolderIfNotExist(OBSTACLE_FOLDER_PATH);
            tabHandler = new TabHandler();
            tabHandler.AddTab(new TabHandler.Tab(ELEMENTS_TAB_LABEL, DrawFieldElementsTab));
            tabHandler.AddTab(new TabHandler.Tab(LEVELS_TAB_LABEL, DrawLevelsTab, OnOpenLevelsTab));
            tabHandler.AddTab(new TabHandler.Tab(TEXTURES_TAB_LABEL, DrawTexturesTab));
            fileNameRegex = new Regex(FILENAME_REGEX_PATTERN, RegexOptions.Singleline);
            texture2DType = typeof(Texture2D);
            paletteCellSize = SPRITE_ELEMENT_SIZE;
            levelCellSize = SPRITE_ELEMENT_SIZE;
            filledGridCells = new List<Vector2Int>();
            draggetItemGridCells = new List<Vector2Int>();
            levelsHandler = new LevelsHandler(levelsDatabaseSerializedObject, levelsSerializedProperty);

            //handle ItemTypes
            itemTypes = new List<LevelElement>();
            itemTypes.Add(new LevelElement(LevelItemType.Obstacle, typeof(Obstacle), obstaclesSerializedProperty, OBSTACLE_FOLDER_PATH, "Obstacles", "Obstacle_0x0"));
            itemTypes.Add(new LevelElement(LevelItemType.Enemy, typeof(Enemy), enemiesSerializedProperty, ENEMY_FOLDER_PATH, "Enemies", "Enemy_0x0"));
        }

        protected override void Styles()
        {
            base.Styles();

            if (tabHandler != null)
            {
                tabHandler.SetDefaultToolbarStyle();
            }
        }

        public override void OpenLevel(UnityEngine.Object levelObject, int index)
        {
            selectedLevelRepresentation = new LevelRepresentation(levelObject);
        }

        public override string GetLevelLabel(UnityEngine.Object levelObject, int index)
        {
            return new LevelRepresentation(levelObject).GetLevelLabel(index, stringBuilder);
        }

        public override void ClearLevel(UnityEngine.Object levelObject)
        {
            new LevelRepresentation(levelObject).Clear();
        }

        protected override void DrawContent()
        {
            tabHandler.toolBarDisabled = itemIsDragged;
            tabHandler.DisplayTab();
            HandleDragOfLevelItem();
        }

        #region tab1
        private void DrawFieldElementsTab()
        {
            for (int i = 0; i < itemTypes.Count; i++)
            {
                itemTypes[i].DrawItemType(fileNameRegex);
            }

            EditorGUILayout.Space();
            EditorGUILayout.HelpBox(ELEMENTS_TAB_INSTRUCTION, MessageType.Info);
        }


        #endregion


        #region useful stuff for tab 1 and 2

        private static void DrawGrid(float startX, float startY, Vector2Int size, float cellSize)
        {
            tempTextureRect = new Rect(startX, startY, LINE_WIDTH, cellSize * size.y);

            for (int i = 0; i <= size.x; i++)
            {
                GUI.DrawTexture(tempTextureRect, Texture2D.whiteTexture);
                tempTextureRect.x += cellSize;
            }

            tempTextureRect = new Rect(startX, startY, cellSize * size.x, LINE_WIDTH);

            for (int i = 0; i <= size.y; i++)
            {
                GUI.DrawTexture(tempTextureRect, Texture2D.whiteTexture);
                tempTextureRect.y += cellSize;
            }
        }

        #endregion

        #region tab 2
        private void OnOpenLevelsTab()
        {
            bool textureisMissing = false;
            string errorLabel = string.Empty;
            stringBuilder.Clear();
            stringBuilder.Append(DEFAULT_TEXTURES_MISSING);
            
            if(itemBackgroundTextureTextureProperty.objectReferenceValue == null)
            {
                if(textureisMissing)
                {
                    stringBuilder.Append(ELEMENT_SEPARATOR);
                }

                stringBuilder.Append(ITEM_BACKGROUND_TEXTURE_PROPERTY_NAME);
                textureisMissing = true;
            }

            if (redTextureProperty.objectReferenceValue == null)
            {
                if (textureisMissing)
                {
                    stringBuilder.Append(ELEMENT_SEPARATOR);
                }

                stringBuilder.Append(RED_TEXTURE_PROPERTY_NAME);
                textureisMissing = true;
            }

            if (itemBackgroundTextureTextureProperty.objectReferenceValue == null)
            {
                if (textureisMissing)
                {
                    stringBuilder.Append(ELEMENT_SEPARATOR);
                }

                stringBuilder.Append(ITEM_BACKGROUND_TEXTURE_PROPERTY_NAME);
                textureisMissing = true;
            }

            if (placeholderTextureProperty.objectReferenceValue == null)
            {
                if (textureisMissing)
                {
                    stringBuilder.Append(ELEMENT_SEPARATOR);
                }

                stringBuilder.Append(PLACEHOLDER_TEXTURE_PROPERTY_NAME);
                textureisMissing = true;
            }

            if(textureisMissing)
            {
                stringBuilder.Append(LINE_SEPARATOR);
                errorLabel = stringBuilder.ToString();
            }
            else
            {
                stringBuilder.Clear();
            }

            FieldElement fieldElement;
            

            for (int i = 0; i < itemTypes.Count; i++)
            {
                itemTypes[i].CreateCached();

                stringBuilder.Append(itemTypes[i].label + TEXTURES_MISSING);
                textureisMissing = false;

                for (int cachedIndex = 0; cachedIndex < itemTypes[i].cached.Length; cachedIndex++)
                {
                    fieldElement = GetFieldElementFromObject(itemTypes[i].arrayProperty.GetArrayElementAtIndex(cachedIndex));
                    itemTypes[i].cached[cachedIndex] = fieldElement;

                    if (fieldElement == null)
                    {
                        if (textureisMissing)
                        {
                            stringBuilder.Append(ELEMENT_SEPARATOR);
                        }

                        if (itemTypes[i].arrayProperty.GetArrayElementAtIndex(cachedIndex).objectReferenceValue != null)
                        {
                            stringBuilder.Append(itemTypes[i].arrayProperty.GetArrayElementAtIndex(cachedIndex).objectReferenceValue.name);
                        }
                        else
                        {
                            stringBuilder.Append(NULL_OBJECT);
                        }

                        textureisMissing = true;
                    }
                }

                if (textureisMissing)
                {
                    stringBuilder.Append(LINE_SEPARATOR);
                    errorLabel = stringBuilder.ToString();
                }
                else
                {
                    stringBuilder.Clear();
                    stringBuilder.Append(errorLabel);
                }
            }

            if (errorLabel.Length > 0)
            {
                tabHandler.SetTabIndex(0);
                EditorUtility.DisplayDialog(ERROR, errorLabel, OK);
            }

        }

        private FieldElement GetFieldElementFromObject(SerializedProperty objectProperty)
        {
            if (objectProperty.objectReferenceValue == null)
            {
                return null;
            }

            SerializedObject serializedObject = new SerializedObject(objectProperty.objectReferenceValue);
            return ParseFieldElement(serializedObject.FindProperty(FIELD_ELEMENT_PROPERTY_NAME));
        }

        private FieldElement ParseFieldElement(SerializedProperty fieldElementProperty)
        {
            textureSerializedProperty = fieldElementProperty.FindPropertyRelative(TEXTURE_PROPERTY_NAME);

            if (textureSerializedProperty.objectReferenceValue == null)
            {
                return null;
            }

            horizontalOffsetSerializedProperty = fieldElementProperty.FindPropertyRelative(HORIZIONTAL_OFFSET_PROPERTY_NAME);
            verticalOffsetSerializedProperty = fieldElementProperty.FindPropertyRelative(VERTICAL_OFFSET_PROPERTY_NAME);
            sizeSerializedProperty = fieldElementProperty.FindPropertyRelative(SIZE_PROPERTY_NAME);

            return new FieldElement((Texture2D)textureSerializedProperty.objectReferenceValue, horizontalOffsetSerializedProperty.floatValue, verticalOffsetSerializedProperty.floatValue, sizeSerializedProperty.vector2IntValue);
        }

        private void DrawLevelsTab()
        {
            EditorGUILayout.BeginHorizontal();
            BeginDisabledGroup(itemIsDragged);
            EditorGUILayout.BeginVertical(GUILayout.Width(SIDEBAR_WIDTH));
            levelsHandler.DisplayReordableList();
            levelsHandler.DrawRenameLevelsButton();
            EditorGUILayout.EndVertical();
            EndDisabledGroup();

            GUILayout.Space(8);

            levelRect = EditorGUILayout.BeginVertical();
            levelScrolVector = EditorGUILayout.BeginScrollView(levelScrolVector);
            EditorGUILayout.BeginVertical();
            DrawOpenLevel();
            EditorGUILayout.EndVertical();
            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();
            EditorGUILayout.EndHorizontal();
        }

        private void DrawOpenLevel()
        {
            if (levelsHandler.SelectedLevelIndex == -1)
            {
                return;
            }

            if (IsPropertyChanged(levelsHandler.SelectedLevelProperty, new GUIContent("file: ")))
            {
                levelsHandler.ReopenLevel();
            }

            if (selectedLevelRepresentation.NullLevel)
            {
                return;
            }

            DrawVariables();
            GUILayout.Space(START_OFFSET);
            DrawLevelGrid();

            for (int i = 0; i < itemTypes.Count; i++)
            {
                DrawFieldElementsPalette(itemTypes[i]);
            }

            DisplayLevelTutorialInfo();

            selectedLevelRepresentation.ApplyChanges();
        }



        private void DrawVariables()
        {
            BeginDisabledGroup(itemIsDragged);
            paletteCellSize = EditorGUILayout.IntField(PALETTE_CELL_SIZE, paletteCellSize);
            levelCellSize = EditorGUILayout.IntField(LEVEL_CELL_SIZE, levelCellSize); ;
            EditorGUILayout.PropertyField(selectedLevelRepresentation.sizeProperty);
            EndDisabledGroup();
        }

        private void DrawLevelGrid()
        {
            groupRect = EditorGUILayout.BeginVertical(GUILayout.MinHeight(selectedLevelRepresentation.sizeProperty.vector2IntValue.y * levelCellSize));

            if (groupRect.yMin != 0)
            {
                levelGridPositionY = groupRect.yMin + levelRect.yMin - levelScrolVector.y;
                levelGridPositionX = groupRect.xMin + levelRect.xMin - levelScrolVector.x;
            }

            DrawGrid(groupRect.xMin, groupRect.yMin, selectedLevelRepresentation.sizeProperty.vector2IntValue, levelCellSize);

            for (int i = 0; i < itemTypes.Count; i++)
            {
                DrawLevelItems(groupRect.xMin, groupRect.yMin, itemTypes[i],selectedLevelRepresentation.GetLevelArrayProperty(itemTypes[i].type));
            }


            GUILayout.Space(selectedLevelRepresentation.sizeProperty.vector2IntValue.y * levelCellSize);
            EditorGUILayout.EndVertical();
            EditorGUILayout.Space();
        }

        private void DrawLevelItems(float startX, float startY, LevelElement itemType, SerializedProperty levelArraySerializedProperty)
        {
            int cachedIndex;
            int angle;
            Vector2Int position;
            FieldElement fieldElement;


            for (int i = 0; i < levelArraySerializedProperty.arraySize; i++)
            {
                if (itemIsDragged && (draggetItemType == itemType.type) && (draggedItemLevelIndex == i))
                {
                    continue;
                }

                selectedLevelRepresentation.GetLevelItem(levelArraySerializedProperty, i, itemType.arrayProperty, out cachedIndex, out angle, out position);
                fieldElement = itemType.cached[cachedIndex];

                itemUIGridPosition = new Vector2Int(position.x, selectedLevelRepresentation.sizeProperty.vector2IntValue.y - 1 - position.y);
                itemPosition = Vector2.one * itemUIGridPosition * levelCellSize + FieldElement.GetOffset(levelCellSize, angle);
                itemPosition.x += startX;
                itemPosition.y += startY;

                DrawRotatedTexture(itemPosition, angle, levelCellSize, fieldElement, true, true, delegate
                {
                    if (!itemIsDragged)
                    {
                        draggetItemAngle = angle;
                        draggetItemType = itemType.type;
                        draggetItemSource = SourceType.FromLevel;
                        draggedItemLevelIndex = i;
                        draggedItemCachedIndex = cachedIndex;

                        UpdateLevelFilledGridCell();
                        itemIsDragged = true;
                    }
                    else
                    {
                        currentEvent = Event.current;

                        if(currentEvent.button == 1)
                        {
                            draggetItemAngle = (draggetItemAngle + 90) % 360; //rotate currently selected object 
                        }
                    }
                });
            }
        }

        private void DrawRotatedTexture(Vector2 itemPosition, int itemAngle, float cellSize, FieldElement fieldElement, bool displayItemBackground, bool isButton, Action onClickCallBack)
        {
            matrixBackup = GUI.matrix;

            fullRect = fieldElement.GetFullRect(itemPosition.x, itemPosition.y, cellSize);
            textureRect = fieldElement.GetRect(itemPosition.x, itemPosition.y, cellSize);

            if ((itemAngle != 0) && ((Screen.width - fullRect.xMax < 30) || (Screen.height - fullRect.yMax + contentScrollViewVector.y < 30)))
            {
                secondRotatingPoint = itemPosition;
                firstRotatingPoint = secondRotatingPoint - fullRect.size;
                fullRect.position = firstRotatingPoint - fullRect.size;
                textureRect = fieldElement.GetRect(fullRect.position.x, fullRect.position.y, cellSize);

                //GUI.DrawTexture(fullRect, greenTexture, ScaleMode.StretchToFill); debug stuff
                GUIUtility.RotateAroundPivot(180, firstRotatingPoint);
                //GUI.DrawTexture(fullRect, redTexture, ScaleMode.StretchToFill);   debug stuff
                GUIUtility.RotateAroundPivot(180 + itemAngle, secondRotatingPoint);
            }
            else
            {
                GUIUtility.RotateAroundPivot(itemAngle, itemPosition);
            }

            if (displayItemBackground)
            {
                GUI.DrawTexture(fullRect, itemBackgroundTexture, ScaleMode.StretchToFill);
            }

            GUI.DrawTexture(textureRect, fieldElement.Texture, ScaleMode.ScaleToFit);

            if (isButton)
            {
                if (GUI.Button(fullRect, GUIContent.none, GUIStyle.none))
                {
                    onClickCallBack?.Invoke();
                }
            }

            GUI.matrix = matrixBackup;
        }

        private void DrawFieldElementsPalette(LevelElement itemType)
        {
            EditorGUILayout.LabelField(itemType.label);

            groupRect = EditorGUILayout.BeginVertical();
            startPosX = groupRect.xMin + START_OFFSET;
            startPosY = groupRect.yMin + START_OFFSET;
            maxHeight = 0f;

            for (int i = 0; i < itemType.cached.Length; i++)
            {
                if (startPosX + itemType.cached[i].GetWidth(paletteCellSize) < Screen.width)
                {
                    textureRect = itemType.cached[i].GetRect(startPosX, startPosY, paletteCellSize);
                    GUI.DrawTexture(textureRect, itemType.cached[i].Texture, ScaleMode.ScaleToFit);
                    DrawGrid(startPosX, startPosY, itemType.cached[i].Size, paletteCellSize);

                    startPosX += textureRect.width + START_OFFSET;

                    if (maxHeight < textureRect.height)
                    {
                        maxHeight = textureRect.height;
                    }
                }
                else
                {
                    startPosX = groupRect.xMin + START_OFFSET;
                    startPosY += maxHeight + START_OFFSET;
                    maxHeight = 0;
                    textureRect = itemType.cached[i].GetRect(startPosX, startPosY, paletteCellSize);
                    GUI.DrawTexture(textureRect, itemType.cached[i].Texture, ScaleMode.ScaleToFit);
                    DrawGrid(startPosX, startPosY, itemType.cached[i].Size, paletteCellSize);

                    startPosX += textureRect.width + START_OFFSET;

                    if (maxHeight < textureRect.height)
                    {
                        maxHeight = textureRect.height;
                    }

                }


                //handle drag start
                if (!itemIsDragged)
                {
                    currentEvent = Event.current;

                    if (textureRect.Contains(currentEvent.mousePosition))
                    {
                        if (currentEvent.type == EventType.MouseDown)
                        {

                            draggetItemAngle = 0;
                            draggetItemType = itemType.type;
                            draggetItemSource = SourceType.FromPalette;
                            draggedItemLevelIndex = -1;
                            draggedItemCachedIndex = i;

                            UpdateLevelFilledGridCell();
                            itemIsDragged = true;
                            currentEvent.Use();
                        }
                    }
                }
            }

            startPosY += maxHeight + START_OFFSET;

            GUILayout.Space(startPosY - groupRect.yMin);
            EditorGUILayout.EndVertical();
        }



        #region Handle drag

        private void UpdateLevelFilledGridCell()
        {
            filledGridCells.Clear();
            int cachedIndex;
            int angle;
            Vector2Int position;
            SerializedProperty levelArrayProperty;

            for (int i = 0; i < itemTypes.Count; i++)
            {
                levelArrayProperty = selectedLevelRepresentation.GetLevelArrayProperty(itemTypes[i].type);

                for (int j = 0; j < levelArrayProperty.arraySize; j++)
                {
                    if ((draggetItemSource == SourceType.FromLevel) && (draggetItemType == itemTypes[i].type) && (draggedItemLevelIndex == i))
                    {
                        continue;
                    }

                    selectedLevelRepresentation.GetLevelItem(levelArrayProperty, j, itemTypes[i].arrayProperty, out cachedIndex, out angle, out position);
                    filledGridCells.AddRange(itemTypes[i].cached[cachedIndex].GetGridCells(new Vector2Int(position.x, selectedLevelRepresentation.sizeProperty.vector2IntValue.y - 1 - position.y), angle));
                }
            }
        }

        private void Update()
        {
            if (itemIsDragged)
            {
                Repaint();
            }
        }
        private void HandleDragOfLevelItem()
        {
            if (!itemIsDragged)
            {
                return;
            }

            currentEvent = Event.current;

            if (currentEvent == null)
            {
                return;
            }

            HandleDragEvents();

            //find element position
            draggetItemUIGridPosition.x = Mathf.FloorToInt((currentEvent.mousePosition.x - levelGridPositionX) / levelCellSize);
            draggetItemUIGridPosition.y = Mathf.FloorToInt((currentEvent.mousePosition.y - levelGridPositionY) / levelCellSize);

            //snap if inside grid
            if ((draggetItemUIGridPosition.x >= 0) && (draggetItemUIGridPosition.x < selectedLevelRepresentation.sizeProperty.vector2IntValue.x) &&
                (draggetItemUIGridPosition.y >= 0) && (draggetItemUIGridPosition.y < selectedLevelRepresentation.sizeProperty.vector2IntValue.y))
            {
                draggetItemSnapActive = true;
                rectPosition.x = (draggetItemUIGridPosition.x * levelCellSize + levelGridPositionX);
                rectPosition.y = (draggetItemUIGridPosition.y * levelCellSize + levelGridPositionY);
                texturePointRect = new Rect(rectPosition, new Vector2(levelCellSize, levelCellSize));
                rectPosition += FieldElement.GetOffset(levelCellSize, draggetItemAngle);
                UpdateDragStatusForLevelItem();
            }
            else
            {
                draggetItemSnapActive = false;
                rectPosition = currentEvent.mousePosition;
                texturePointRect = new Rect(rectPosition, new Vector2(levelCellSize, levelCellSize));
                draggetItemDropAcceptable = false;
            }

            //draw dragged item
            DrawRotatedTexture(rectPosition, draggetItemAngle, levelCellSize, GetDraggedFieldElement(), true, false, null);

            //element position cell in grid
            if (draggetItemSnapActive)
            {
                if (draggetItemDropAcceptable)
                {
                    GUI.DrawTexture(texturePointRect, greenTexture, ScaleMode.ScaleAndCrop);
                }
                else
                {
                    GUI.DrawTexture(texturePointRect, redTexture, ScaleMode.ScaleAndCrop);
                }
            }
        }

        private void HandleDragEvents()
        {
            switch (currentEvent.type)
            {
                case EventType.MouseLeaveWindow:
                    itemIsDragged = false;
                    currentEvent.Use();
                    break;
                case EventType.MouseDown:

                    if (currentEvent.button == 0)
                    {
                        if (draggetItemDropAcceptable)
                        {
                            UpdateLevelItem();
                            itemIsDragged = false;
                        }
                        else
                        {
                            if (!draggetItemSnapActive)
                            {
                                if (draggetItemSource == SourceType.FromLevel)
                                {
                                    selectedLevelRepresentation.RemoveItem(selectedLevelRepresentation.GetLevelArrayProperty(draggetItemType), draggedItemLevelIndex);
                                }

                                itemIsDragged = false;
                            }
                        }
                    }

                    currentEvent.Use();
                    break;

                case EventType.ContextClick:
                    draggetItemAngle = (draggetItemAngle + 90) % 360;
                    currentEvent.Use();
                    break;
                default:
                    break;
            }
        }

        private FieldElement GetDraggedFieldElement()
        {
            for (int i = 0; i < itemTypes.Count; i++)
            {
                if(itemTypes[i].type == draggetItemType)
                {
                    return itemTypes[i].cached[draggedItemCachedIndex];
                }
            }

            return null;
        }

        private void UpdateLevelItem()
        {
            Vector2Int draggetItemLevelGridPosition = new Vector2Int(draggetItemUIGridPosition.x, selectedLevelRepresentation.sizeProperty.vector2IntValue.y - 1 - draggetItemUIGridPosition.y);

            if(draggetItemSource == SourceType.FromLevel)
            {
                selectedLevelRepresentation.UpdateItem(selectedLevelRepresentation.GetLevelArrayProperty(draggetItemType), draggetItemAngle, draggetItemLevelGridPosition, draggedItemLevelIndex);
            }
            else
            {
                selectedLevelRepresentation.CreateItem(selectedLevelRepresentation.GetLevelArrayProperty(draggetItemType), draggetItemAngle, draggetItemLevelGridPosition, GetItemTypeArray(draggetItemType).GetArrayElementAtIndex(draggedItemCachedIndex));
            }
        }

        private SerializedProperty GetItemTypeArray(LevelItemType levelItemType)
        {
            for (int i = 0; i < itemTypes.Count; i++)
            {
                if(itemTypes[i].type == levelItemType)
                {
                    return itemTypes[i].arrayProperty;
                }
            }

            return null;
        }

        private void UpdateDragStatusForLevelItem()
        {
            draggetItemGridCells.Clear();
            draggetItemGridCells.AddRange(GetDraggedFieldElement().GetGridCells(draggetItemUIGridPosition, draggetItemAngle));
            draggetItemDropAcceptable = true;

            foreach (Vector2Int cell in draggetItemGridCells)
            {
                if ((cell.x < 0) || (cell.y < 0) || (cell.x >= selectedLevelRepresentation.sizeProperty.vector2IntValue.x) || (cell.y >= selectedLevelRepresentation.sizeProperty.vector2IntValue.y))
                {
                    draggetItemDropAcceptable = false;
                    break;
                }

                if (filledGridCells.Contains(cell))
                {
                    draggetItemDropAcceptable = false;
                    break;
                }
            }
        }
        #endregion


        private void DisplayLevelTutorialInfo()
        {
            EditorGUILayout.HelpBox("Use left click to select object.", MessageType.Info);
            EditorGUILayout.HelpBox("Use left click to place selected object.", MessageType.Info);
            EditorGUILayout.HelpBox("Use right click to rotate selected object.", MessageType.Info);
            EditorGUILayout.HelpBox("Place object outside of grid to remove object from grid.", MessageType.Info);
            EditorGUILayout.HelpBox("All changes save automatically.", MessageType.Info);
            EditorGUILayout.HelpBox("Green cell show position of selected object.", MessageType.Info);
            EditorGUILayout.HelpBox("Red cell means that you can`t place object in this cell.", MessageType.Info);
            EditorGUILayout.HelpBox("Enemies can only be placed at least one cell away from grid border of grid.", MessageType.Info);
        }
        #endregion

        #region tab 3

        private void DrawTexturesTab()
        {
            if (IsPropertyChanged(placeholderTextureProperty))
            {
                placeholderTexture = (Texture2D)placeholderTextureProperty.objectReferenceValue;
            }

            if (IsPropertyChanged(greenTextureProperty))
            {
                greenTexture = (Texture2D)greenTextureProperty.objectReferenceValue;
            }

            if (IsPropertyChanged(redTextureProperty))
            {
                redTexture = (Texture2D)redTextureProperty.objectReferenceValue;
            }

            if (IsPropertyChanged(itemBackgroundTextureTextureProperty))
            {
                itemBackgroundTexture = (Texture2D)itemBackgroundTextureTextureProperty.objectReferenceValue;
            }
        }

        #endregion

        public enum LevelItemType
        {
            Obstacle = 0,
            Enemy = 1
        }

        public enum SourceType
        {
            FromPalette,
            FromLevel
        }

        private class LevelElement
        {
            public LevelItemType type;
            public Type objectType;
            public SerializedProperty arrayProperty;
            public string defaultNewFileName;
            public string currentNewFileName;
            public string folderPath;
            public string label;
            private Rect clickRect;
            private int selectedIndex;
            private SerializedObject selectedObject;

            //field element
            private const string FIELD_ELEMENT_PROPERTY_NAME = "fieldElement";
            private const string TEXTURE_PROPERTY_NAME = "texture";
            private const string HORIZIONTAL_OFFSET_PROPERTY_NAME = "horizontalOffset";
            private const string VERTICAL_OFFSET_PROPERTY_NAME = "verticalOffset";
            private const string SIZE_PROPERTY_NAME = "size";
            private const string FIELD_ELEMENT_LABEL = "Field element:";
            private const string FILENAME = "Filename";
            private Rect tempTextureRect;
            private Event currentEvent;
            private Rect textureRect;
            private Texture2D texture;
            private Rect textureFieldRect;
            private SerializedProperty horizontalOffsetSerializedProperty;
            private SerializedProperty verticalOffsetSerializedProperty;
            private SerializedProperty sizeSerializedProperty;
            private SerializedProperty textureSerializedProperty;

            //
            public int indexOfRemovedElement;
            public FieldElement[] cached;

            public LevelElement(LevelItemType itemType, Type objectType, SerializedProperty arrayProperty, string folderPath, string label, string defaultNewFileName)
            {
                this.type = itemType;
                this.objectType = objectType;
                this.arrayProperty = arrayProperty;
                this.folderPath = folderPath;
                this.label = label;
                this.defaultNewFileName = defaultNewFileName;
                this.currentNewFileName = defaultNewFileName;
                this.selectedIndex = -1;
            }

            public void DrawItemType(Regex fileNameRegex)
            {
                EditorGUILayout.LabelField(label);
                currentNewFileName = EditorGUILayout.TextField(NEW_OBJECT_LABEL, currentNewFileName);
                DrawCreateObjectButton(fileNameRegex, folderPath + PATH_SEPARATOR + currentNewFileName + ASSET_SUFFIX);
                EditorGUILayout.Space();
                HandleTypeList();
            }

            private void DrawCreateObjectButton(Regex fileNameRegex,string filePath)
            {
                if (fileNameRegex.IsMatch(currentNewFileName) && (!System.IO.File.Exists(GetProjectPath() + filePath)))
                {
                    if (GUILayout.Button(CREATE_OBJECT_LABEL, EditorStylesExtended.button_01))
                    {
                        CreateAsset(objectType, arrayProperty, filePath);
                        currentNewFileName = defaultNewFileName;
                    }
                }
                else
                {
                    if (!fileNameRegex.IsMatch(currentNewFileName))
                    {
                        BeginDisabledGroup(true);
                        GUILayout.Button(CREATE_OBJECT_LABEL, EditorStylesExtended.button_01);
                        EndDisabledGroup();
                        EditorGUILayout.HelpBox(FILENAME_INCORRECT_ERROR + FILENAME_REGEX_PATTERN, MessageType.Error);
                    }
                    else
                    {
                        BeginDisabledGroup(true);
                        GUILayout.Button(CREATE_OBJECT_LABEL, EditorStylesExtended.button_01);
                        EndDisabledGroup();
                        EditorGUILayout.HelpBox(FILE_ALREADY_EXIST_ERROR, MessageType.Error);
                    }
                }
            }

            private void CreateAsset(Type fileType, SerializedProperty arrayProperty, string filePath)
            {
                ScriptableObject newFile = ScriptableObject.CreateInstance(fileType);
                AssetDatabase.CreateAsset(newFile, filePath);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                arrayProperty.arraySize++;
                arrayProperty.GetArrayElementAtIndex(arrayProperty.arraySize - 1).objectReferenceValue = newFile;
            }

            private void HandleTypeList()
            {
                indexOfRemovedElement = -1;

                for (int i = 0;i < arrayProperty.arraySize; i++)
                {
                    clickRect = EditorGUILayout.BeginVertical();

                    if ((i == selectedIndex) && (LevelsEditorWindow.selectedType == type))
                    {
                        DisplaySelectedObject(selectedObject, i, arrayProperty);
                    }
                    else
                    {
                        DisplayUnselectedObject(i);
                    }

                    EditorGUILayout.EndVertical();

                    if (GUI.Button(clickRect, GUIContent.none, GUIStyle.none))
                    {

                        if (selectedIndex == i)
                        {
                            selectedIndex = -1;
                        }
                        else
                        {
                            if (arrayProperty.GetArrayElementAtIndex(i).objectReferenceValue != null)
                            {
                                selectedIndex = i;
                                LevelsEditorWindow.selectedType = type;
                                selectedObject = new SerializedObject((ScriptableObject)arrayProperty.GetArrayElementAtIndex(i).objectReferenceValue);
                                SerializedProperty fieldElementProperty = selectedObject.FindProperty(FIELD_ELEMENT_PROPERTY_NAME);
                                textureSerializedProperty = fieldElementProperty.FindPropertyRelative(TEXTURE_PROPERTY_NAME);
                                horizontalOffsetSerializedProperty = fieldElementProperty.FindPropertyRelative(HORIZIONTAL_OFFSET_PROPERTY_NAME);
                                verticalOffsetSerializedProperty = fieldElementProperty.FindPropertyRelative(VERTICAL_OFFSET_PROPERTY_NAME);
                                sizeSerializedProperty = fieldElementProperty.FindPropertyRelative(SIZE_PROPERTY_NAME);
                            }
                        }
                    }
                }

                if(indexOfRemovedElement != -1)
                {
                    Debug.Log("HandleRemove Called");
                    HandleRemove(indexOfRemovedElement);
                    indexOfRemovedElement = -1;
                    
                }
            }


            private void DisplaySelectedObject(SerializedObject serializedObject, int index, SerializedProperty arrayProperty)
            {
                EditorGUILayout.LabelField(FILENAME, serializedObject.targetObject.name);

                SerializedProperty iterator = serializedObject.GetIterator();
                iterator.NextVisible(true);

                do
                {
                    if ((!iterator.name.Equals(FIELD_ELEMENT_PROPERTY_NAME)) && (!iterator.name.Equals(SOURSE_SCRIPT_PROPERTY_NAME)))
                    {
                        EditorGUILayout.PropertyField(iterator);
                    }

                } while (iterator.NextVisible(false));

                HandleFieldElement(serializedObject.FindProperty(FIELD_ELEMENT_PROPERTY_NAME));

                serializedObject.ApplyModifiedProperties();

                if (GUILayout.Button(DELETE_LABEL, EditorStylesExtended.button_01))
                {
                    indexOfRemovedElement = index;
                }
            }

            private void HandleFieldElement(SerializedProperty fieldElementProperty)
            {
                EditorGUILayout.BeginVertical();
                EditorGUILayout.LabelField(FIELD_ELEMENT_LABEL);


                EditorGUILayout.PropertyField(horizontalOffsetSerializedProperty);
                EditorGUILayout.PropertyField(verticalOffsetSerializedProperty);
                EditorGUILayout.PropertyField(sizeSerializedProperty);


                textureFieldRect = EditorGUILayout.BeginVertical(GUILayout.MinHeight(SPRITE_ELEMENT_SIZE * sizeSerializedProperty.vector2IntValue.y + START_OFFSET * 2));
                textureRect = new Rect(START_OFFSET + textureFieldRect.xMin, START_OFFSET + textureFieldRect.yMin, SPRITE_ELEMENT_SIZE * sizeSerializedProperty.vector2IntValue.x, SPRITE_ELEMENT_SIZE * sizeSerializedProperty.vector2IntValue.y);
                GUILayout.Space(SPRITE_ELEMENT_SIZE * sizeSerializedProperty.vector2IntValue.y + START_OFFSET * 2);

                //handle drag and drop of texture
                currentEvent = Event.current;

                if (textureRect.Contains(currentEvent.mousePosition))
                {
                    if (currentEvent.type == EventType.DragUpdated)
                    {
                        if ((DragAndDrop.objectReferences.Length == 1) && (DragAndDrop.objectReferences[0].GetType() == texture2DType))
                        {
                            DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
                        }
                        else
                        {
                            DragAndDrop.visualMode = DragAndDropVisualMode.Rejected;
                        }

                        currentEvent.Use();
                    }
                    else if (currentEvent.type == EventType.DragPerform)
                    {
                        if ((DragAndDrop.objectReferences.Length == 1) && (DragAndDrop.objectReferences[0].GetType() == texture2DType))
                        {
                            textureSerializedProperty.objectReferenceValue = DragAndDrop.objectReferences[0];
                        }

                        currentEvent.Use();
                    }
                }



                if (textureSerializedProperty.objectReferenceValue == null)
                {
                    GUI.DrawTexture(textureRect, placeholderTexture);
                }
                else
                {
                    textureRect = new Rect(START_OFFSET + textureFieldRect.xMin + horizontalOffsetSerializedProperty.floatValue,
                        START_OFFSET + textureFieldRect.yMin + horizontalOffsetSerializedProperty.floatValue,
                        SPRITE_ELEMENT_SIZE * sizeSerializedProperty.vector2IntValue.x - (horizontalOffsetSerializedProperty.floatValue * 2f),
                        SPRITE_ELEMENT_SIZE * sizeSerializedProperty.vector2IntValue.y - (verticalOffsetSerializedProperty.floatValue * 2f));

                    texture = (Texture2D)textureSerializedProperty.objectReferenceValue;

                    GUI.DrawTexture(textureRect, texture, ScaleMode.ScaleToFit);

                }

                DrawGrid(textureFieldRect.xMin + START_OFFSET, textureFieldRect.yMin + START_OFFSET, sizeSerializedProperty.vector2IntValue, SPRITE_ELEMENT_SIZE);

                EditorGUILayout.EndVertical();
                EditorGUILayout.EndVertical();
            }

            private void DisplayUnselectedObject(int index)
            {
                clickRect = EditorGUILayout.BeginHorizontal(GUI.skin.box);
                EditorGUILayout.PropertyField(arrayProperty.GetArrayElementAtIndex(index));

                if (GUILayout.Button(DELETE_LABEL, EditorStylesExtended.button_01, GUILayout.MaxWidth(60f)))
                {
                    indexOfRemovedElement = index;
                }

                EditorGUILayout.EndHorizontal();
            }



            private void HandleRemove(int index)
            {
                UnityEngine.Object removable = arrayProperty.GetArrayElementAtIndex(index).objectReferenceValue;
                arrayProperty.DeleteArrayElementAtIndex(index);

                if (removable != null)
                {
                    AssetDatabase.DeleteAsset(AssetDatabase.GetAssetPath(removable));
                    AssetDatabase.Refresh();
                }
            }

            public void CreateCached()
            {
                cached = new FieldElement[arrayProperty.arraySize];
            }
        }

        protected class LevelRepresentation : LevelRepresentationBase
        {
            private const string SIZE_PROPERTY_NAME = "size";
            private const string OBSTACLES_PROPERTY_NAME = "obstacles";
            private const string ENEMIES_PROPERTY_NAME = "enemies";
            private const string ELEMENT_PROPERTY_NAME = "element";
            private const string POSITION_PROPERTY_NAME = "position";
            private const string ANGLE_PROPERTY_NAME = "angle";
            private readonly Vector2Int LEVEL_MIN_SIZE = new Vector2Int(10, 10);
            private readonly Vector2Int LEVEL_MAX_SIZE = new Vector2Int(50, 50);

            public SerializedProperty sizeProperty;
            public SerializedProperty obstaclesProperty;
            public SerializedProperty enemiesProperty;

            private SerializedProperty tempElementProperty;
            private SerializedProperty tempPositionProperty;
            private SerializedProperty tempAngleProperty;

            public LevelRepresentation(UnityEngine.Object levelObject) : base(levelObject)
            {
            }

            protected override void ReadFields()
            {
                sizeProperty = serializedLevelObject.FindProperty(SIZE_PROPERTY_NAME);
                obstaclesProperty = serializedLevelObject.FindProperty(OBSTACLES_PROPERTY_NAME);
                enemiesProperty = serializedLevelObject.FindProperty(ENEMIES_PROPERTY_NAME);
            }

            public void HandleSizeChange()
            {
                if (sizeProperty.vector2IntValue.x < LEVEL_MIN_SIZE.x)
                {
                    sizeProperty.vector2IntValue = new Vector2Int(LEVEL_MIN_SIZE.x, sizeProperty.vector2IntValue.y);
                }
                else if (sizeProperty.vector2IntValue.x > LEVEL_MAX_SIZE.x)
                {
                    sizeProperty.vector2IntValue = new Vector2Int(LEVEL_MAX_SIZE.x, sizeProperty.vector2IntValue.y);
                }

                if (sizeProperty.vector2IntValue.y < LEVEL_MIN_SIZE.y)
                {
                    sizeProperty.vector2IntValue = new Vector2Int(sizeProperty.vector2IntValue.x, LEVEL_MIN_SIZE.y);
                }
                else if (sizeProperty.vector2IntValue.y > LEVEL_MAX_SIZE.y)
                {
                    sizeProperty.vector2IntValue = new Vector2Int(sizeProperty.vector2IntValue.x, LEVEL_MAX_SIZE.y);
                }

            }

            public override void Clear()
            {
                sizeProperty.vector2IntValue = LEVEL_MIN_SIZE;
                obstaclesProperty.arraySize = 0;
                enemiesProperty.arraySize = 0;
            }

            public void GetLevelItem(SerializedProperty levelArrayProperty, int levelArrayIndex, SerializedProperty databaseArray, out int cachedElementIndex, out int angle, out Vector2Int position)
            {
                for (int i = 0; i < databaseArray.arraySize; i++)
                {
                    tempElementProperty = levelArrayProperty.GetArrayElementAtIndex(levelArrayIndex).FindPropertyRelative(ELEMENT_PROPERTY_NAME);

                    if (tempElementProperty.objectReferenceValue == databaseArray.GetArrayElementAtIndex(i).objectReferenceValue)
                    {
                        tempAngleProperty = levelArrayProperty.GetArrayElementAtIndex(levelArrayIndex).FindPropertyRelative(ANGLE_PROPERTY_NAME);
                        tempPositionProperty = levelArrayProperty.GetArrayElementAtIndex(levelArrayIndex).FindPropertyRelative(POSITION_PROPERTY_NAME);
                        cachedElementIndex = i;
                        angle = tempAngleProperty.intValue;
                        position = tempPositionProperty.vector2IntValue;
                        return;
                    }
                }

                Debug.LogError("Unknown element encountered. Element removed.");
                levelArrayProperty.DeleteArrayElementAtIndex(levelArrayIndex);
                cachedElementIndex = -1;
                angle = 0;
                position = Vector2Int.zero;
            }

            public void CreateItem(SerializedProperty levelArrayProperty, int angle, Vector2Int position, SerializedProperty element)
            {
                levelArrayProperty.arraySize++;
                int index = levelArrayProperty.arraySize - 1;
                levelArrayProperty.GetArrayElementAtIndex(index).FindPropertyRelative(ELEMENT_PROPERTY_NAME).objectReferenceValue = element.objectReferenceValue;
                levelArrayProperty.GetArrayElementAtIndex(index).FindPropertyRelative(ANGLE_PROPERTY_NAME).intValue = angle;
                levelArrayProperty.GetArrayElementAtIndex(index).FindPropertyRelative(POSITION_PROPERTY_NAME).vector2IntValue = position;
                ApplyChanges();
            }

            public void UpdateItem(SerializedProperty levelArrayProperty, int angle, Vector2Int position, int index)
            {
                levelArrayProperty.GetArrayElementAtIndex(index).FindPropertyRelative(ANGLE_PROPERTY_NAME).intValue = angle;
                levelArrayProperty.GetArrayElementAtIndex(index).FindPropertyRelative(POSITION_PROPERTY_NAME).vector2IntValue = position;
                ApplyChanges();
            }

            public void RemoveItem(SerializedProperty levelArrayProperty, int index)
            {
                levelArrayProperty.DeleteArrayElementAtIndex(index);
                ApplyChanges();
            }

            public SerializedProperty GetLevelArrayProperty(LevelItemType itemType)
            {
                if(itemType == LevelItemType.Obstacle)
                {
                    return obstaclesProperty;
                }
                else
                {
                    return enemiesProperty;
                }
            }
        }
    }
}

// -----------------
// 2d grid with objects level editor v 1.2
// -----------------

// Changelog
// v 1.2
// • Fixed bug with object rotation
// • Fixed bug with new level list
// • Added ItemType class to quicly Edit new type
// • Added ItemType class to quicly Edit new type

// v 1.1
// • Reordered some methods
// v 1.1
// • Fixed errors
// • Fixed new element names
// v 1 basic version works