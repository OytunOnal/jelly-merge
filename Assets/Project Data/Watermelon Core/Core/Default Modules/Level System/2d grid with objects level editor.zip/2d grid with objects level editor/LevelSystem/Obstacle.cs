﻿#pragma warning disable 649
using UnityEngine;

namespace Watermelon
{
    public class Obstacle : ScriptableObject
    {
        [SerializeField] private FieldElement fieldElement;

        [SerializeField] private GameObject prefab;

        public GameObject Prefab => prefab;
        public Vector2Int Size => fieldElement.Size;
    }
}