﻿#pragma warning disable 649

using UnityEngine;

namespace Watermelon
{
    public class Level : ScriptableObject
    {
        [SerializeField] Vector2Int size;

        [SerializeField] ObstacleData[] obstacles;
        [SerializeField] EnemyData[] enemies;

        public int ObstaclesCount => obstacles.Length;
        public int EnemiesCount => enemies.Length;

        public ObstacleData GetObstacleData(int index)
        {
            if (index < 0 || index >= ObstaclesCount)
            {
                return null;
            }

            return obstacles[index];
        }

        public EnemyData GetEnemyData(int index)
        {
            if (index < 0 || index >= EnemiesCount)
            {
                return null;
            }

            return enemies[index];
        }

        /* In case new Data classes needs to be added there are few requirements. This requirements make working with classes easier and 
         * help reduce code duplication to minimum. Requirements:
         * 1) Each Data class have 3 fields : "element", "position", "angle".
         * 2) "position" and "angle" fields is the same in each class.
         * 3) Element field inherits from ScriptableObject and have "fieldElement" field.
         */

        [System.Serializable]
        public class ObstacleData
        {
            [SerializeField] Obstacle element;
            [SerializeField] Vector2Int position;
            [SerializeField] int angle;

            public Obstacle Obstacle => element;
            public Vector2Int Position => position;
            public int Angle => angle;
        }

        [System.Serializable]
        public class EnemyData
        {
            [SerializeField] Enemy element;
            [SerializeField] Vector2Int position;
            [SerializeField] int angle;

            public Enemy Enemy => element;
            public Vector2Int Position => position;
            public int Angle => angle;
        }
    }

}