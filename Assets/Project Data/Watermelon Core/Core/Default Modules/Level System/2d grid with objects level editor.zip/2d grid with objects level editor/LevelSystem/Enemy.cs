﻿#pragma warning disable 649

using UnityEngine;

namespace Watermelon
{
    public class Enemy : ScriptableObject
    {
        [SerializeField] private FieldElement fieldElement;
        [SerializeField] private GameObject prefab;
        [SerializeField] private bool isBoss;
        [SerializeField] private float maxHP;

        public GameObject Prefab => prefab;
        public Vector2Int Size => fieldElement.Size;
        public bool IsBoss => isBoss;
        public float MaxHP => maxHP;
    }
}
