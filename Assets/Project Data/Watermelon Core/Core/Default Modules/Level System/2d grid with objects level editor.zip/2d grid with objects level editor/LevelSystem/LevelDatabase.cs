﻿#pragma warning disable 649

using UnityEngine;

namespace Watermelon
{

    public class LevelDatabase : ScriptableObject
    {
        [SerializeField] Level[] levels;

        [SerializeField] Enemy[] enemies;
        [SerializeField] Obstacle[] obstacles;

        //Editor stuff
        [SerializeField] Texture2D placeholderTexture;
        [SerializeField] Texture2D greenTexture;
        [SerializeField] Texture2D redTexture;
        [SerializeField] Texture2D itemBackgroundTexture;

        public int LevelsCount => levels.Length;

        public int EnemiesCount => enemies.Length;
        public int ObstaclesCount => obstacles.Length;

        public Level GetLevel(int index)
        {
            if (index < 0 || index >= LevelsCount) return null;

            return levels[index];
        }

        public Enemy GetEnemy(int index)
        {
            if (index < 0 || index >= EnemiesCount) return null;

            return enemies[index];
        }

        public Obstacle GetObstacle(int index)
        {
            if (index < 0 || index >= ObstaclesCount) return null;

            return obstacles[index];
        }

        public int GetNextLevelId(int levelId, bool isOverflow)
        {
            if (!isOverflow)
            {
                return levelId + 1;
            }
            else
            {
                int nextLevel;

                do
                {
                    nextLevel = Random.Range(0, LevelsCount);
                } while (nextLevel == levelId);

                return nextLevel;
            }
        }
    }
}