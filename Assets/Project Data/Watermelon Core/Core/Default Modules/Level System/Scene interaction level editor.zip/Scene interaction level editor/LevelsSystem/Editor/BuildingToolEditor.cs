using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Watermelon;
using UnityEditor;
using System;

[CustomEditor(typeof(BuildingTool))]
public class BuildingToolEditor : Editor
{
    
    public const string BUILDING_PARTS_PROPERTY_NAME = "buildingParts";
    public const string BUILDING_PARTS_ENUM_PROPERTY_NAME = "buildingPartsEnum";
    public const string CONNECT_POINTS_PROPERTY_NAME = "connectPoints";
    public const string CONNECTIONS_PROPERTY_NAME = "connections";

    public const string CONNECT_POINT_INDEX_PROPERTY_NAME = "connectionPointIndex";
    public const string BUILDING_PART_INDEX_PROPERTY_NAME = "buildingPartIndex";
    public const string POSITION_OFFSET_PROPERTY_NAME = "positionOffset";
    public const string ROTATION_OFFSET_PROPERTY_NAME = "rotationOffset";
    public const string ENABLED_PROPERTY_NAME = "enabled";
    public const string COLOR_PROPERTY_NAME = "color";
    public const float SPHERE_SIZE = 0.25f;



    private SerializedProperty builingPartsProperty;
    private SerializedProperty buildingPartsEnumProperty;
    private SerializedProperty connectPointsProperty;
    private SerializedProperty connectionsProperty;
    private SerializedProperty connectPointProperty;
    private SerializedProperty connectionProperty;

    private BuildingTool buildingTool;

    private int selectedTabIndex;
    private int tempTabIndex;
    private string[] tabs = { "LevelBuilding", "BuilingParts", "ConnectionPoints", "Connections" };

    private int selectedIndexInCollectionPointTab = -1;
    private List<int> connectPointsIndexes;
    private List<int> connectionsIndexes;
    private Rect buttonRect;
    private Rect collorRect;
    private bool displayGizmo;
    private GameObject primaryGameobject;
    private GameObject secondaryGameobject;
    private GameObject lastSelectedGameobject;
    private List<Transform> gizmoTransforms;
    private Transform primaryGizmoTransform;
    private Color defaultHandlesColor;
    private int selectedIndexInConnectionsTab;
    private int tempInt;
    private string labelFrom;
    private string labelTo;
    private SerializedProperty enabledProperty;
    private SerializedProperty positionOffsetProperty;
    private SerializedProperty rotationOffsetProperty;

    private int selectedConnectPoint;
    private bool trackSelection;
    private bool buildingMenuLoaded;
    private SavableItem tempSavableItem;



    private void OnEnable()
    {
        builingPartsProperty = serializedObject.FindProperty(BUILDING_PARTS_PROPERTY_NAME);
        buildingPartsEnumProperty = serializedObject.FindProperty(BUILDING_PARTS_ENUM_PROPERTY_NAME);
        connectPointsProperty = serializedObject.FindProperty(CONNECT_POINTS_PROPERTY_NAME);
        connectionsProperty = serializedObject.FindProperty(CONNECTIONS_PROPERTY_NAME);

        buildingTool = serializedObject.targetObject as BuildingTool;
        selectedTabIndex = -1;
        connectPointsIndexes = new List<int>();
        connectionsIndexes = new List<int>();
        defaultHandlesColor = Handles.color;
        selectedIndexInConnectionsTab = -1;
        selectedIndexInCollectionPointTab = -1;
        gizmoTransforms = new List<Transform>();
    }

    


    public override void OnInspectorGUI()
    {
        tempTabIndex = GUILayout.SelectionGrid(selectedTabIndex, tabs, 1);
        EditorGUILayout.Space();

        if(tempTabIndex != selectedTabIndex)
        {
            InitTab(tempTabIndex);
        }

        selectedTabIndex = tempTabIndex;

        switch (selectedTabIndex)
        {
            case 0:
                DisplayLevelBuildingTab();
                break;
            case 1:
                DisplayBuilingPartsTab();
                break;
            case 2:
                DisplayConnectionPointsTab();
                break;
            case 3:
                DisplayConnectionsTab();
                break;
            default:
                break;

        }

        serializedObject.ApplyModifiedProperties();
    }

    private void InitTab(int tabIndex)
    {
        buildingMenuLoaded = false;
        selectedConnectPoint = -1;
        selectedIndexInCollectionPointTab = -1;
        selectedIndexInConnectionsTab = -1;
        ClearChildren();
    }

    private void DisplayLevelBuildingTab()
    {
        trackSelection = EditorGUILayout.Toggle("track selection", trackSelection);

        if (!buildingMenuLoaded)
        {
            return;
        }

        for (int connectPointIndex = 0; connectPointIndex < connectPointsIndexes.Count; connectPointIndex++)
        {
            buttonRect =  EditorGUILayout.BeginHorizontal();
                       
            LevelEditorBase.DrawColorRect(GUILayoutUtility.GetRect(30,EditorGUIUtility.singleLineHeight), connectPointsProperty.GetArrayElementAtIndex(connectPointsIndexes[connectPointIndex]).FindPropertyRelative(COLOR_PROPERTY_NAME).colorValue);
            
            if(connectPointIndex == selectedConnectPoint)
            {
                EditorGUILayout.LabelField("Point #" + (connectPointIndex + 1) + " (selected)");
            }
            else
            {
                EditorGUILayout.LabelField("Point #" + (connectPointIndex + 1));
            }
            
            EditorGUILayout.EndHorizontal();

            if (GUI.Button(buttonRect, GUIContent.none, GUIStyle.none))
            {
                selectedConnectPoint = connectPointIndex;
                FindConnections(connectPointsIndexes[selectedConnectPoint]);
            }
        }

        if(selectedConnectPoint != -1)
        {
            for (int i = 0; i < connectionsIndexes.Count; i++)
            {
                tempInt = connectionsProperty.GetArrayElementAtIndex(connectionsIndexes[i]).FindPropertyRelative(BUILDING_PART_INDEX_PROPERTY_NAME).intValue;

                if (GUILayout.Button(builingPartsProperty.GetArrayElementAtIndex(tempInt).objectReferenceValue.name))
                {
                    UnityEngine.Object prefab = builingPartsProperty.GetArrayElementAtIndex(tempInt).objectReferenceValue;
                    Vector3 position = primaryGameobject.transform.position + connectionsProperty.GetArrayElementAtIndex(connectionsIndexes[i]).FindPropertyRelative(POSITION_OFFSET_PROPERTY_NAME).vector3Value;
                    Vector3 rotationEuler = connectionsProperty.GetArrayElementAtIndex(connectionsIndexes[i]).FindPropertyRelative(ROTATION_OFFSET_PROPERTY_NAME).vector3Value;
                    GameObject temp = (GameObject) Instantiate(prefab, position, Quaternion.Euler(rotationEuler), primaryGameobject.transform.parent);
                    temp.transform.RotateAround(primaryGameobject.transform.position, Vector3.up, primaryGameobject.transform.localEulerAngles.y);
                    Selection.activeGameObject = temp;
                }
            }

            GUILayout.Space(30);

            if (GUILayout.Button("Close"))
            {
                buildingMenuLoaded = false;
                selectedConnectPoint = -1;
                ClearChildren();
            }
        }
    }

    private void LoadBuildingMenu(Item item)
    {
        int buildingPartIndex = -1;

        for (int i = 0; i < buildingPartsEnumProperty.arraySize; i++)
        {
            if ((Item)buildingPartsEnumProperty.GetArrayElementAtIndex(i).enumValueIndex == item)
            {
                buildingPartIndex = i;
                break;
            }
        }

        if (buildingPartIndex == -1)
        {
            connectPointsIndexes.Clear();
            ClearChildren();
            return;
        }

        FindConnectionPoints(buildingPartIndex);
        ClearChildren();
        SetUpGizmoTransforms();
        selectedConnectPoint = -1;
        buildingMenuLoaded = true;
    }

    private void FindConnections(int connectPointIndex)
    {
        connectionsIndexes.Clear();

        for (int i = 0; i < connectionsProperty.arraySize; i++)
        {
            if (connectionsProperty.GetArrayElementAtIndex(i).FindPropertyRelative(CONNECT_POINT_INDEX_PROPERTY_NAME).intValue == connectPointIndex)
            {
                if (connectionsProperty.GetArrayElementAtIndex(i).FindPropertyRelative(ENABLED_PROPERTY_NAME).boolValue) // in separate if because it may be removed in the future 
                {
                    connectionsIndexes.Add(i);
                    Debug.Log("Connection index: " + i);
                }
                
            }
        }
    }

    private void DisplayBuilingPartsTab()
    {
        EditorGUILayout.PropertyField(builingPartsProperty);
        EditorGUILayout.PropertyField(buildingPartsEnumProperty);
        EditorGUILayout.HelpBox("Arrays should match.", MessageType.Info);
    }

    private void DisplayConnectionPointsTab()
    {
        for (int i = 0; i < builingPartsProperty.arraySize; i++)
        {
            if (selectedIndexInCollectionPointTab == i)
            {
                buttonRect = EditorGUILayout.BeginVertical(GUI.skin.box);
                EditorGUILayout.LabelField(builingPartsProperty.GetArrayElementAtIndex(i).objectReferenceValue.name);
                EditorGUILayout.LabelField("Connect points:");

                for (int j = 0; j < connectPointsIndexes.Count; j++)
                {
                    connectPointProperty = connectPointsProperty.GetArrayElementAtIndex(connectPointsIndexes[j]);

                    EditorGUILayout.PropertyField(connectPointProperty.FindPropertyRelative(POSITION_OFFSET_PROPERTY_NAME));
                    EditorGUILayout.PropertyField(connectPointProperty.FindPropertyRelative(COLOR_PROPERTY_NAME));

                }

                if(GUILayout.Button("Use default colors"))
                {
                    for (int colorIndex = 0; (colorIndex < connectPointsIndexes.Count) && (colorIndex < 8); colorIndex++)
                    {
                        connectPointProperty = connectPointsProperty.GetArrayElementAtIndex(connectPointsIndexes[colorIndex]);
                        connectPointProperty.FindPropertyRelative(COLOR_PROPERTY_NAME).colorValue = GetDefaultColor(colorIndex);
                    }
                }


                if (GUILayout.Button("Add"))
                {
                    AddConnectionPoint(selectedIndexInCollectionPointTab);
                }

                if (GUILayout.Button("RemoveLast"))
                {
                    connectPointsProperty.DeleteArrayElementAtIndex(connectPointsIndexes[connectPointsIndexes.Count - 1]);
                    connectPointsIndexes.RemoveAt(connectPointsIndexes.Count - 1);
                    DestroyImmediate(gizmoTransforms[gizmoTransforms.Count - 1].gameObject);
                }

                if (GUILayout.Button("Close"))
                {
                    
                    ClearChildren();
                    selectedIndexInCollectionPointTab = -1;
                }
                
                EditorGUILayout.EndVertical();

            }
            else
            {
                buttonRect = EditorGUILayout.BeginVertical(GUI.skin.box);
                EditorGUILayout.LabelField(builingPartsProperty.GetArrayElementAtIndex(i).objectReferenceValue.name);
                EditorGUILayout.EndVertical();

                if (GUI.Button(buttonRect, GUIContent.none, GUIStyle.none))
                {
                    selectedIndexInCollectionPointTab = i;
                    FindConnectionPoints(i);
                    InitPrimaryGameobject(i);
                }
            }
        }
    }


    private Color GetDefaultColor(int index)
    {
        switch (index)
        {
            case 0: return Color.red;
            case 1: return Color.green;
            case 2: return Color.blue;
            case 3: return Color.yellow;
            case 4: return Color.magenta;
            case 5: return Color.cyan;
            case 6: return Color.white;
            case 7: return Color.black;
            default: return Color.gray;
        }
    }
    

    private void FindConnectionPoints(int buildingPartIndex)
    {
        connectPointsIndexes.Clear();

        for (int i = 0; i < connectPointsProperty.arraySize; i++)
        {
            if(connectPointsProperty.GetArrayElementAtIndex(i).FindPropertyRelative(BUILDING_PART_INDEX_PROPERTY_NAME).intValue == buildingPartIndex)
            {
                connectPointsIndexes.Add(i);
            }
        }
    }

    

    private void AddConnectionPoint(int buildingPartIndex)
    {
        connectPointsProperty.arraySize++;
        connectPointProperty = connectPointsProperty.GetArrayElementAtIndex(connectPointsProperty.arraySize - 1);
        connectPointProperty.FindPropertyRelative(BUILDING_PART_INDEX_PROPERTY_NAME).intValue = buildingPartIndex;
        connectPointProperty.FindPropertyRelative(POSITION_OFFSET_PROPERTY_NAME).vector3Value = Vector3.zero;
        connectPointProperty.FindPropertyRelative(COLOR_PROPERTY_NAME).colorValue = new Color(UnityEngine.Random.Range(0f, 1f), UnityEngine.Random.Range(0f, 1f), UnityEngine.Random.Range(0f, 1f));
        connectPointsIndexes.Add(connectPointsProperty.arraySize - 1);
        gizmoTransforms.Add(new GameObject("Gizmo #" + (connectPointsIndexes.Count)).transform);
        gizmoTransforms[gizmoTransforms.Count - 1].SetParent(primaryGizmoTransform);
    }

    private void InitPrimaryGameobject(int buildingPartIndex)
    {
        ClearChildren();

        primaryGameobject = (GameObject)Instantiate(builingPartsProperty.GetArrayElementAtIndex(buildingPartIndex).objectReferenceValue, Vector3.zero, Quaternion.identity, buildingTool.transform);
        SetUpGizmoTransforms();
    }

    private void ClearChildren()
    {
        displayGizmo = false;

        for (int i = buildingTool.transform.childCount - 1; i >= 0; i--)
        {
            DestroyImmediate(buildingTool.transform.GetChild(i).gameObject);
        }

        gizmoTransforms.Clear();
    }

    private void SetUpGizmoTransforms()
    {
        primaryGizmoTransform = new GameObject("Gizmo transforms container").transform;
        primaryGizmoTransform.position = primaryGameobject.transform.position;
        primaryGizmoTransform.SetParent(buildingTool.transform);

        for (int i = 0; i < connectPointsIndexes.Count; i++)
        {
            gizmoTransforms.Add(new GameObject("Gizmo #" + (i + 1)).transform);
            gizmoTransforms[i].SetParent(primaryGizmoTransform);
        }

        displayGizmo = true;
    }

    

    private void OnSceneGUI()
    {
        if (trackSelection && (selectedTabIndex == 0))
        {
            if((Selection.activeGameObject != null) && (Selection.activeGameObject != lastSelectedGameobject))
            {
                lastSelectedGameobject = Selection.activeGameObject;
                tempSavableItem = lastSelectedGameobject.GetComponent<SavableItem>();

                if(tempSavableItem != null)
                {
                    primaryGameobject = lastSelectedGameobject;
                    LoadBuildingMenu(tempSavableItem.Item);
                }
            }

            if((primaryGizmoTransform != null) && (primaryGameobject != null))
            {
                primaryGizmoTransform.position = primaryGameobject.transform.position;
                primaryGizmoTransform.rotation = primaryGameobject.transform.rotation;
            }
        }

        if (!displayGizmo)
        {
            return;
        }

        for (int i = 0; i < connectPointsIndexes.Count; i++)
        {
            connectPointProperty = connectPointsProperty.GetArrayElementAtIndex(connectPointsIndexes[i]);
            gizmoTransforms[i].localPosition = connectPointProperty.FindPropertyRelative(POSITION_OFFSET_PROPERTY_NAME).vector3Value;

            Handles.color = connectPointProperty.FindPropertyRelative(COLOR_PROPERTY_NAME).colorValue;
            Handles.SphereHandleCap(0, gizmoTransforms[i].position, Quaternion.identity, SPHERE_SIZE, EventType.Repaint);
            Handles.Label(gizmoTransforms[i].position, "Point #" + (i + 1));
        }

        Handles.color = defaultHandlesColor;
    }

    

    private void DisplayConnectionsTab()
    {
        if(GUILayout.Button("Fill Connections"))
        {
            FillConncections();
        }

        tempInt = Mathf.Clamp(EditorGUILayout.IntField("Index:", tempInt), 0, connectionsProperty.arraySize - 1);

        if (GUILayout.Button("Load"))
        {
            LoadConnection(tempInt);
        }

        EditorGUILayout.Space();



        if (selectedIndexInConnectionsTab != -1)
        {
            EditorGUILayout.LabelField("Connection index:", selectedIndexInConnectionsTab + " / " + (connectionsProperty.arraySize - 1));
            EditorGUILayout.LabelField("From:", labelFrom);
            EditorGUILayout.LabelField("To:", labelTo);
            EditorGUILayout.PropertyField(enabledProperty);
            EditorGUILayout.PropertyField(positionOffsetProperty);
            EditorGUILayout.PropertyField(rotationOffsetProperty);

            if(GUILayout.Button("Fill from scene"))
            {
                positionOffsetProperty.vector3Value = secondaryGameobject.transform.position - primaryGameobject.transform.position;
                rotationOffsetProperty.vector3Value = secondaryGameobject.transform.rotation.eulerAngles - primaryGameobject.transform.rotation.eulerAngles;
            }

            if (GUILayout.Button("Update objects on scene"))
            {
                secondaryGameobject.transform.position = primaryGameobject.transform.position + positionOffsetProperty.vector3Value;
                secondaryGameobject.transform.rotation = Quaternion.Euler( primaryGameobject.transform.rotation.eulerAngles + positionOffsetProperty.vector3Value);
            }

            EditorGUI.BeginDisabledGroup(selectedIndexInConnectionsTab + 1 == connectionsProperty.arraySize);

            if (GUILayout.Button("Next"))
            {
                LoadConnection(selectedIndexInConnectionsTab + 1);
            }

            EditorGUI.EndDisabledGroup();

            if (GUILayout.Button("Close"))
            {
                ClearChildren();
                selectedIndexInConnectionsTab = -1;
            }
        }
    }

    

    private void FillConncections()
    {
        connectionsProperty.arraySize = 0;

        for (int builingPart1Index = 0; builingPart1Index < builingPartsProperty.arraySize; builingPart1Index++)
        {
            FindConnectionPoints(builingPart1Index);

            for (int buildingPart2Index = 0; buildingPart2Index < builingPartsProperty.arraySize; buildingPart2Index++)
            {
                for (int connectionPointIndex = 0; connectionPointIndex < connectPointsIndexes.Count; connectionPointIndex++)
                {
                    connectionsProperty.arraySize++;
                    connectionProperty = connectionsProperty.GetArrayElementAtIndex(connectionsProperty.arraySize - 1);
                    connectionProperty.FindPropertyRelative(CONNECT_POINT_INDEX_PROPERTY_NAME).intValue = connectPointsIndexes[connectionPointIndex];
                    connectionProperty.FindPropertyRelative(BUILDING_PART_INDEX_PROPERTY_NAME).intValue = buildingPart2Index;
                    connectionProperty.FindPropertyRelative(POSITION_OFFSET_PROPERTY_NAME).vector3Value = new Vector3(2,0,2); //default value that don`t spawn 2 elements in the same place
                    connectionProperty.FindPropertyRelative(ROTATION_OFFSET_PROPERTY_NAME).vector3Value = Vector3.zero;
                    connectionProperty.FindPropertyRelative(ENABLED_PROPERTY_NAME).boolValue = true;
                }
            }
        }
    }

    private void LoadConnection(int connectionIndex)
    {
        //loaded data from arrays
        connectionProperty = connectionsProperty.GetArrayElementAtIndex(connectionIndex);
        selectedIndexInConnectionsTab = connectionIndex;
        int connectPointIndex = connectionProperty.FindPropertyRelative(CONNECT_POINT_INDEX_PROPERTY_NAME).intValue;
        int buildingPart1Index = connectPointsProperty.GetArrayElementAtIndex(connectPointIndex).FindPropertyRelative(BUILDING_PART_INDEX_PROPERTY_NAME).intValue;
        int buildingPart2Index = connectionProperty.FindPropertyRelative(BUILDING_PART_INDEX_PROPERTY_NAME).intValue;
        labelFrom = builingPartsProperty.GetArrayElementAtIndex(buildingPart1Index).objectReferenceValue.name;
        labelTo = builingPartsProperty.GetArrayElementAtIndex(buildingPart2Index).objectReferenceValue.name;
        enabledProperty = connectionProperty.FindPropertyRelative(ENABLED_PROPERTY_NAME);
        positionOffsetProperty = connectionProperty.FindPropertyRelative(POSITION_OFFSET_PROPERTY_NAME);
        rotationOffsetProperty = connectionProperty.FindPropertyRelative(ROTATION_OFFSET_PROPERTY_NAME);

        //set up objects
        connectPointsIndexes.Clear();
        connectPointsIndexes.Add(connectPointIndex);
        ClearChildren();
        primaryGameobject = (GameObject)Instantiate(builingPartsProperty.GetArrayElementAtIndex(buildingPart1Index).objectReferenceValue, Vector3.zero, Quaternion.identity, buildingTool.transform);
        secondaryGameobject = (GameObject)Instantiate(builingPartsProperty.GetArrayElementAtIndex(buildingPart2Index).objectReferenceValue, positionOffsetProperty.vector3Value, Quaternion.Euler(rotationOffsetProperty.vector3Value), buildingTool.transform);
        SetUpGizmoTransforms();
    }
}
