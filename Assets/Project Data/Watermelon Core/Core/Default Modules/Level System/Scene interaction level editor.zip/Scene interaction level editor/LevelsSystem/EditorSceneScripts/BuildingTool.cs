using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace Watermelon
{
    //[ExecuteInEditMode]
    public class BuildingTool : MonoBehaviour
    {
        [SerializeField] GameObject[] buildingParts;
        [SerializeField] Item[] buildingPartsEnum;
        [SerializeField] ConnectPoint[] connectPoints;
        [SerializeField] Connection[] connections;

        [System.Serializable]
        public class Connection
        {
            public int connectionPointIndex;
            public int buildingPartIndex; // index of builingPart we connect to
            public Vector3 positionOffset;
            public Vector3 rotationOffset;
            public bool enabled;
        }



        [System.Serializable]
        public class ConnectPoint
        {
            public int buildingPartIndex;
            public Vector3 positionOffset;
            public Color color;
        }
    }
}
