﻿namespace Watermelon
{
	public enum Item
	{
		Cube = 0,
		Sphere = 1,
		Cylinder = 2,
	}
}