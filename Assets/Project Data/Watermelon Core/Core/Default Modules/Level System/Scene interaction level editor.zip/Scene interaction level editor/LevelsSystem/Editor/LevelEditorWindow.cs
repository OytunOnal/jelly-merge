﻿#pragma warning disable 649

using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System;
using Watermelon;
using System.Text;

public class LevelEditorWindow : LevelEditorBase
{

    //Path variables need to be changed ----------------------------------------
    private const string ENUM_FILE_PATH = "Assets/Project Data/Watermelon Core/Core/Default Modules/Level System/Scene interraction level editor/Scene interraction level editor/LevelsSystem/ItemEnum.cs";
    private const string GAME_SCENE_PATH = "Assets/Project Data/Game/Scenes/Game.unity";
    private const string EDITOR_SCENE_PATH = "Assets/Project Data/Watermelon Core/Core/Default Modules/Level System/Scene interraction level editor/Scene interraction level editor/Example/LevelEditor.unity";
    private static string EDITOR_SCENE_NAME = "LevelEditor";
    private bool USE_LEVEL_EDITOR_SCENE = true;

    //Window configuration
    private const string TITLE = "Level Editor";
    private const float WINDOW_MIN_WIDTH = 600;
    private const float WINDOW_MIN_HEIGHT = 560;
    private const float WINDOW_MAX_WIDTH = 800;
    private const float WINDOW_MAX_HEIGHT = 700;

    //Level database fields
    private const string LEVELS_PROPERTY_NAME = "levels";
    private const string ITEMS_PROPERTY_NAME = "items";
    private SerializedProperty levelsSerializedProperty;
    private SerializedProperty itemsSerializedProperty;

    //EnumObjectsList 
    private const string TYPE_PROPERTY_PATH = "type";
    private const string PREFAB_PROPERTY_PATH = "prefab";
    private const string SPAWN_POSITION_PROPERTY_PATH = "spawnPosition";
    private bool enumCompiling;
    private EnumObjectsList enumObjectsList;

    //TabHandler
    private TabHandler tabHandler;
    private const string LEVELS_TAB_NAME = "Levels";
    private const string ITEMS_TAB_NAME = "Items";

    //sidebar
    private LevelsHandler levelsHandler;
    private LevelRepresentation selectedLevelRepresentation;
    private const int SIDEBAR_WIDTH = 240;
    private const string OPEN_GAME_SCENE_LABEL = "Open \"Game\" scene";

    private const string OPEN_GAME_SCENE_WARNING = "Please make sure you saved changes before swiching scene. Are you ready to proceed?";
    private const string REMOVE_SELECTION = "Remove selection";

    //ItemSave
    private const string POSITION_PROPERTY_PATH = "position";
    private const string ROTATION_PROPERTY_PATH = "rotation";
    private const string SCALE_PROPERTY_PATH = "scale";

    //General
    private const string YES = "Yes";
    private const string CANCEL = "Cancel";
    private const string WARNING_TITLE = "Warning";
    private SerializedProperty tempProperty;
    private string tempPropertyLabel;

    //rest of levels tab
    private const string ITEMS_LABEL = "Spawn items:";
    private const string FILE = "file:";
    private const string OBJECT_MANAGEMENT = "Object management:";
    private const string CLEAR_SCENE = "Clear scene";
    private const string SAVE = "Save";
    private const string LOAD = "Load";
    private const string REMOVE = "Remove";
    private const string COMPILING = "Compiling...";
    private const string ITEM_UNASSIGNED_ERROR = "Please assign prefab to this item in \"Items\"  tab.";
    private const string ITEM_ASSIGNED = "This buttton spawns item.";
    private const string TEST_LEVEL = "Test level";

    private const float ITEMS_BUTTON_MAX_WIDTH = 120;
    private const float ITEMS_BUTTON_SPACE = 8;
    private const float ITEMS_BUTTON_WIDTH = 80;
    private const float ITEMS_BUTTON_HEIGHT = 80;
    private const string RENAME_LEVELS = "Rename Levels";
    private bool prefabAssigned;
    private GUIContent itemContent;
    private SerializedProperty currentLevelItemProperty;
    private Vector2 levelItemsScrollVector;
    private float itemPosX;
    private float itemPosY;
    private Rect itemsRect;
    private Rect selectedLevelFieldRect;
    private Rect itemRect;
    private int itemsPerRow;
    private int rowCount;
    private GameObject tempGameobject;
    private Item tempItem;
    private Vector3 tempPosition;
    private GameObject editorGameobject;
    private bool createdEditorGameobject;

    protected override WindowConfiguration SetUpWindowConfiguration(WindowConfiguration.Builder builder)
    {
        builder.KeepWindowOpenOnScriptReload(true);
        builder.SetWindowMinSize(new Vector2(WINDOW_MIN_WIDTH, WINDOW_MIN_HEIGHT));
        builder.SetContentMaxSize(new Vector2(WINDOW_MAX_WIDTH, WINDOW_MAX_HEIGHT));
        builder.SetWindowMaxSize(new Vector2(WINDOW_MAX_WIDTH, WINDOW_MAX_HEIGHT));
        return builder.Build();
    }

    protected override Type GetLevelsDatabaseType()
    {
        return typeof(LevelsDatabase);
    }

    public override Type GetLevelType()
    {
        return typeof(Level);
    }

    protected override void ReadLevelDatabaseFields()
    {
        levelsSerializedProperty = levelsDatabaseSerializedObject.FindProperty(LEVELS_PROPERTY_NAME);
        itemsSerializedProperty = levelsDatabaseSerializedObject.FindProperty(ITEMS_PROPERTY_NAME);
    }

    protected override void InitialiseVariables()
    {
        if (!USE_LEVEL_EDITOR_SCENE)
        {
            SetUpEditorSceneController();
        }

        enumCompiling = false;
        levelsHandler = new LevelsHandler(levelsDatabaseSerializedObject, levelsSerializedProperty);
        enumObjectsList = new EnumObjectsList(itemsSerializedProperty, TYPE_PROPERTY_PATH, PREFAB_PROPERTY_PATH, ENUM_FILE_PATH, OnBeforeEnumFileupdateCallback);
        tabHandler = new TabHandler();
        tabHandler.AddTab(new TabHandler.Tab(LEVELS_TAB_NAME, DisplayLevelsTab));
        tabHandler.AddTab(new TabHandler.Tab(ITEMS_TAB_NAME, enumObjectsList.DisplayTab));
        PrefsSettings.InitEditor();
    }

    private void OnBeforeEnumFileupdateCallback()
    {
        enumCompiling = true;
    }

    protected override void Styles()
    {
        if (tabHandler != null)
        {
            tabHandler.SetDefaultToolbarStyle();
        }
    }

    public override void OpenLevel(UnityEngine.Object levelObject, int index)
    {
        SaveLevelIfPosssible();
        selectedLevelRepresentation = new LevelRepresentation(levelObject);
        levelsHandler.UpdateCurrentLevelLabel(GetLevelLabel(levelObject, index));
        LoadLevelItems();
    }

    public override string GetLevelLabel(UnityEngine.Object levelObject, int index)
    {
        LevelRepresentation levelRepresentation = new LevelRepresentation(levelObject);
        return levelRepresentation.GetLevelLabel(index, stringBuilder);
    }

    public override void ClearLevel(UnityEngine.Object levelObject)
    {
        LevelRepresentation levelRepresentation = new LevelRepresentation(levelObject);
        levelRepresentation.Clear();
    }

    protected override void DrawContent()
    {
        if (USE_LEVEL_EDITOR_SCENE && (EditorSceneManager.GetActiveScene().name != EDITOR_SCENE_NAME))
        {
            DrawOpenEditorScene();
            return;
        }

        if (enumCompiling)
        {
            EditorGUILayout.LabelField(COMPILING,EditorStylesExtended.label_large_bold);
            return;
        }

        tabHandler.DisplayTab();
    }

    private void DrawOpenEditorScene()
    {
        EditorGUILayout.BeginVertical();
        EditorGUILayout.HelpBox(EDITOR_SCENE_NAME + " scene required for level editor.", MessageType.Error, true);

        if (GUILayout.Button("Open \""+ EDITOR_SCENE_NAME + "\" scene"))
        {
            OpenScene(EDITOR_SCENE_PATH);
        }

        EditorGUILayout.EndVertical();
    }

    private void DisplayLevelsTab()
    {
        EditorGUILayout.BeginHorizontal();
        //sidebar 
        EditorGUILayout.BeginVertical(GUI.skin.box, GUILayout.MaxWidth(SIDEBAR_WIDTH));
        levelsHandler.DisplayReordableList();
        DisplaySidebarButtons();
        EditorGUILayout.EndVertical();

        GUILayout.Space(8);

        //level content
        EditorGUILayout.BeginVertical(GUI.skin.box);
        DisplaySelectedLevel();
        EditorGUILayout.EndVertical();
        
        EditorGUILayout.EndHorizontal();
    }

    private void DisplaySidebarButtons()
    {
        if (GUILayout.Button(RENAME_LEVELS, EditorStylesExtended.button_01))
        {
            SaveLevelIfPosssible();
            levelsHandler.RenameLevels();
        }

        if (GUILayout.Button(OPEN_GAME_SCENE_LABEL, EditorStylesExtended.button_01))
        {
            if (EditorUtility.DisplayDialog(WARNING_TITLE, OPEN_GAME_SCENE_WARNING, YES, CANCEL))
            {
                SaveLevelIfPosssible();
                OpenScene(GAME_SCENE_PATH);
            }
        }

        if (GUILayout.Button(REMOVE_SELECTION, EditorStylesExtended.button_01))
        {
            SaveLevelIfPosssible();
            levelsHandler.ClearSelection();
            ClearScene();
        }
    }

    private static void ClearScene()
    {
        EditorSceneController.Instance.Clear();
    }

    private void SetAsCurrentLevel()
    {
        //PrefsSettings.SetInt(PrefsSettings.Key.LevelId, levelsHandler.SelectedLevelIndex); 

        EditorSetLevel(levelsHandler.SelectedLevelIndex);
        throw new NotImplementedException();
    }

    public static void EditorSetLevel(int levelIndex)
    {
        //GlobalSave tempSave = SaveController.GetGlobalSave();

        //SimpleIntSave levelIndexSave = tempSave.GetSaveObject<SimpleIntSave>("Level Number");
        //levelIndexSave.Value = levelIndex;

        //SaveController.ForceSave();
    }

    private void DisplaySelectedLevel()
    {
        if (levelsHandler.SelectedLevelIndex == -1)
        {
            return;
        }

        //handle level file field
        EditorGUI.BeginChangeCheck();
        //easy way to know width of available space
        selectedLevelFieldRect = EditorGUILayout.BeginVertical(GUILayout.ExpandWidth(true));
        EditorGUILayout.PropertyField(levelsHandler.SelectedLevelProperty, new GUIContent(FILE));
        EditorGUILayout.EndVertical();


        if (EditorGUI.EndChangeCheck())
        {
            levelsHandler.ReopenLevel();
        }

        if (selectedLevelRepresentation.NullLevel)
        {
            return;
        }

        EditorGUILayout.Space();

        if (GUILayout.Button(TEST_LEVEL, GUILayout.Width(EditorGUIUtility.labelWidth)))
        {
            SaveLevelItems();
            SetAsCurrentLevel();
            OpenScene(GAME_SCENE_PATH);
            EditorApplication.ExecuteMenuItem("Edit/Play");
        }


        DisplayItemsListSection();
        EditorGUILayout.Space();
    }

    private void DisplayItemsListSection()
    {
        EditorGUILayout.LabelField(ITEMS_LABEL);
        levelItemsScrollVector = EditorGUILayout.BeginScrollView(levelItemsScrollVector);

        itemsRect = EditorGUILayout.BeginVertical();
        itemPosX = itemsRect.x;
        itemPosY = itemsRect.y;

        //assigning space
        if (itemsSerializedProperty.arraySize != 0)
        {
            itemsPerRow = Mathf.FloorToInt((Screen.width - SIDEBAR_WIDTH - 20) / (ITEMS_BUTTON_SPACE + ITEMS_BUTTON_WIDTH));
            rowCount = Mathf.CeilToInt((itemsSerializedProperty.arraySize * 1f) / itemsPerRow);
            GUILayout.Space(rowCount * (ITEMS_BUTTON_SPACE + ITEMS_BUTTON_HEIGHT));
        }

        for (int i = 0; i < itemsSerializedProperty.arraySize; i++)
        {
            tempProperty = itemsSerializedProperty.GetArrayElementAtIndex(i);
            tempPropertyLabel = tempProperty.FindPropertyRelative(TYPE_PROPERTY_PATH).enumDisplayNames[tempProperty.FindPropertyRelative(TYPE_PROPERTY_PATH).enumValueIndex];
            prefabAssigned = (tempProperty.FindPropertyRelative(PREFAB_PROPERTY_PATH).objectReferenceValue != null);

            if (prefabAssigned)
            {
                itemContent = new GUIContent(AssetPreview.GetAssetPreview(tempProperty.FindPropertyRelative(PREFAB_PROPERTY_PATH).objectReferenceValue), ITEM_ASSIGNED);
            }
            else
            {
                itemContent = new GUIContent(tempPropertyLabel, ITEM_UNASSIGNED_ERROR);
            }

            //check if need to start new row
            if (itemPosX + ITEMS_BUTTON_SPACE + ITEMS_BUTTON_WIDTH > selectedLevelFieldRect.width - 10)
            {
                itemPosX = itemsRect.x;
                itemPosY = itemPosY + ITEMS_BUTTON_HEIGHT + ITEMS_BUTTON_SPACE;
            }

            itemRect = new Rect(itemPosX, itemPosY, ITEMS_BUTTON_WIDTH, ITEMS_BUTTON_HEIGHT);

            EditorGUI.BeginDisabledGroup(!prefabAssigned);

            if (GUI.Button(itemRect, itemContent, EditorStylesExtended.button_01))
            {
                tempGameobject = (GameObject)tempProperty.FindPropertyRelative(PREFAB_PROPERTY_PATH).objectReferenceValue;
                tempPosition = tempProperty.FindPropertyRelative(SPAWN_POSITION_PROPERTY_PATH).vector3Value;
                tempItem = (Item)tempProperty.FindPropertyRelative(TYPE_PROPERTY_PATH).enumValueIndex;

                if (SceneView.lastActiveSceneView.in2DMode)
                {
                    tempPosition = tempPosition.SetX(SceneView.lastActiveSceneView.camera.transform.position.x);
                }

                EditorSceneController.Instance.Spawn(tempGameobject, tempPosition, tempItem);
            }

            EditorGUI.EndDisabledGroup();

            itemPosX += ITEMS_BUTTON_SPACE + ITEMS_BUTTON_WIDTH;
        }


        EditorGUILayout.EndVertical();
        EditorGUILayout.EndScrollView();
    }

    private void LoadLevelItems()
    {
        EditorSceneController.Instance.Clear();
        ItemSave tempItemSave;

        for (int i = 0; i < selectedLevelRepresentation.itemsProperty.arraySize; i++)
        {
            tempItemSave = PropertyToItemSave(i);
            EditorSceneController.Instance.Spawn(tempItemSave, GetItemPrefab(tempItemSave.Type));
        }
    }

    private void SaveLevelItems()
    {
        ItemSave[] levelItems = EditorSceneController.Instance.GetLevelItems();
        selectedLevelRepresentation.itemsProperty.arraySize = levelItems.Length;

        for (int i = 0; i < levelItems.Length; i++)
        {
            ItemSaveToProperty(levelItems[i], i);
        }

        selectedLevelRepresentation.ApplyChanges();
        levelsHandler.UpdateCurrentLevelLabel(selectedLevelRepresentation.GetLevelLabel(levelsHandler.SelectedLevelIndex, stringBuilder));
        AssetDatabase.SaveAssets();
    }

    private void ItemSaveToProperty(ItemSave levelItem, int index)
    {
        currentLevelItemProperty = selectedLevelRepresentation.itemsProperty.GetArrayElementAtIndex(index);
        currentLevelItemProperty.FindPropertyRelative(TYPE_PROPERTY_PATH).enumValueIndex = (int)levelItem.Type;
        currentLevelItemProperty.FindPropertyRelative(POSITION_PROPERTY_PATH).vector3Value = levelItem.Position;
        currentLevelItemProperty.FindPropertyRelative(ROTATION_PROPERTY_PATH).vector3Value = levelItem.Rotation;
        currentLevelItemProperty.FindPropertyRelative(SCALE_PROPERTY_PATH).vector3Value = levelItem.Scale;
    }

    private ItemSave PropertyToItemSave(int index)
    {
        currentLevelItemProperty = selectedLevelRepresentation.itemsProperty.GetArrayElementAtIndex(index);
        return new ItemSave(
            (Item)currentLevelItemProperty.FindPropertyRelative(TYPE_PROPERTY_PATH).enumValueIndex,
            currentLevelItemProperty.FindPropertyRelative(POSITION_PROPERTY_PATH).vector3Value,
            currentLevelItemProperty.FindPropertyRelative(ROTATION_PROPERTY_PATH).vector3Value,
            currentLevelItemProperty.FindPropertyRelative(SCALE_PROPERTY_PATH).vector3Value);
    }

    private GameObject GetItemPrefab(Item item)
    {
        for (int i = 0; i < itemsSerializedProperty.arraySize; i++)
        {
            if ((Item)itemsSerializedProperty.GetArrayElementAtIndex(i).FindPropertyRelative(TYPE_PROPERTY_PATH).intValue == item)
            {
                return (GameObject)itemsSerializedProperty.GetArrayElementAtIndex(i).FindPropertyRelative(PREFAB_PROPERTY_PATH).objectReferenceValue;
            }
        }

        Debug.LogError("GetItemPrefab element not found");
        return null;
    }

    private void SaveLevelIfPosssible()
    {
        if (UnityEngine.SceneManagement.SceneManager.GetActiveScene().name != EDITOR_SCENE_NAME)
        {
            return;
        }

        if (selectedLevelRepresentation == null)
        {
            return;
        }

        if (selectedLevelRepresentation.NullLevel)
        {
            return;
        }

        try
        {
            SaveLevelItems();
        }
        catch
        {

        }

        levelsHandler.SetLevelLabels();
    }


    private void SetUpEditorSceneController()
    {
        if (EditorSceneController.Instance == null)
        {
            editorGameobject = new GameObject("[Level editor]");
            editorGameobject.hideFlags = HideFlags.DontSave;
            EditorSceneController editorSceneController = editorGameobject.AddComponent<EditorSceneController>();
            editorSceneController.Container = editorGameobject;
            createdEditorGameobject = true;
        }
        else
        {
            createdEditorGameobject = false;
        }

    }

    private void OnDestroy()
    {
        SaveLevelIfPosssible();

        if (createdEditorGameobject)
        {
            DestroyImmediate(editorGameobject);
        }
    }

    protected class LevelRepresentation : LevelRepresentationBase
    {
        private const string ITEMS_PROPERTY_NAME = "items";
        public SerializedProperty itemsProperty;

        //this empty constructor is nessesary
        public LevelRepresentation(UnityEngine.Object levelObject) : base(levelObject)
        {
        }


        protected override void ReadFields()
        {
            itemsProperty = serializedLevelObject.FindProperty(ITEMS_PROPERTY_NAME);
        }

        public override void Clear()
        {
            if (!NullLevel)
            {
                itemsProperty.arraySize = 0;
                ApplyChanges();
            }

        }

        public override string GetLevelLabel(int index, StringBuilder stringBuilder)
        {
            if (NullLevel)
            {
                return base.GetLevelLabel(index, stringBuilder);
            }
            else
            {
                return base.GetLevelLabel(index, stringBuilder) + SEPARATOR + itemsProperty.arraySize;
            }            
        }
    }
}

// -----------------
// Scene interraction level editor V1.6
// -----------------

// Changelog
// v 1.6
// • Replaced "Set as current level" function with playtest level
// • Added autosave
// • Updated object preview
// • Added USE_LEVEL_EDITOR_SCENE bool
// • Small fix for EditorSceneController
// v 1.5
// • Updated Spawner tool
// • Updated list
// v 1.5
// • Added Building tool
// • Updated list
// v 1.4
// • Updated EnumObjectlist
// • Updated object preview
// v 1.4
// • Updated EnumObjectlist
// • Fixed bug with window size
// v 1.3
// • Updated EnumObjectlist
// • Added StartPointHandles script that can be added to gameobjects
// v 1.2
// • Reordered some methods
// v 1.1
// • Added spawner tool
// v 1 basic version works
