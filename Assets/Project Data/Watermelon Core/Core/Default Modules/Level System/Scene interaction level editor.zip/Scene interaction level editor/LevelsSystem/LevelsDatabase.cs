﻿#pragma warning disable 0649

using UnityEngine;

namespace Watermelon
{
    public class LevelsDatabase : ScriptableObject
    {
        private static LevelsDatabase instance;

        [SerializeField] Level[] levels;

        public Level[] Levels
        {
            get => levels;
        }

        public int LevelsAmount
        {
            get => levels.Length;
        }

        [SerializeField] LevelItem[] items;

        public static LevelItem[] Items => instance.items;

        public void Init()
        {
            instance = this;
        }

        public static Level GetLevelByNumber(int number)
        {
            number = Mathf.Clamp(number, 1, number);

            return instance.levels[(number - 1) % instance.levels.Length];
        }

        public LevelItem GetItem(Item itemType)
        {
            foreach (LevelItem item in Items)
            {
                if (item.Type == itemType)
                {
                    return item;
                }
            }

            return null;
        }
    }
}