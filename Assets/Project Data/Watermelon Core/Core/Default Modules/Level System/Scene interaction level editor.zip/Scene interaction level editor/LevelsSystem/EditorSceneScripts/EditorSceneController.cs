﻿#pragma warning disable 649

using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Watermelon
{
    public class EditorSceneController : MonoBehaviour
    {

#if UNITY_EDITOR
        private static EditorSceneController instance;
        public static EditorSceneController Instance { get => instance; }

        [SerializeField] private GameObject container;
        public GameObject Container { get => container; set => container = value; }

        public EditorSceneController()
        {
            instance = this;
        }

        //used when user spawns objects by clicking on object name in level editor
        public void Spawn(GameObject prefab, Vector3 defaultPosition, Item item)
        {
            GameObject gameObject = Instantiate(prefab, defaultPosition, Quaternion.identity, container.transform);
            gameObject.name = prefab.name + " ( Child # " + container.transform.childCount + ")";
            SavableItem savableItem = gameObject.AddComponent<SavableItem>();
            savableItem.Item = item;
            gameObject.hideFlags = HideFlags.DontSave;
            SceneVisibilityManager.instance.DisablePicking(gameObject, true);
            SceneVisibilityManager.instance.EnablePicking(gameObject, false);
            SelectGameObject(gameObject);
        }

        //used when level loads in level editor
        public void Spawn(ItemSave tempItemSave, GameObject prefab)
        {
            GameObject gameObject = Instantiate(prefab, tempItemSave.Position, Quaternion.Euler(tempItemSave.Rotation), container.transform);
            gameObject.name = prefab.name + "(el # " + container.transform.childCount + ")";
            gameObject.transform.localScale = tempItemSave.Scale;
            SavableItem savableItem = gameObject.AddComponent<SavableItem>();
            savableItem.Item = tempItemSave.Type;
            gameObject.hideFlags = HideFlags.DontSave;
            SceneVisibilityManager.instance.DisablePicking(gameObject, true);
            SceneVisibilityManager.instance.EnablePicking(gameObject, false);
            SelectGameObject(gameObject);
        }

        public void SelectGameObject(GameObject selectedGameObject)
        {
            Selection.activeGameObject = selectedGameObject;
        }

        public void Clear()
        {
            container.hideFlags = HideFlags.DontSave;

            for (int i = container.transform.childCount - 1; i >= 0; i--)
            {
                DestroyImmediate(container.transform.GetChild(i).gameObject);
            }
        }

        public ItemSave[] GetLevelItems()
        {
            SavableItem[] savableItems = container.GetComponentsInChildren<SavableItem>();
            List<ItemSave> result = new List<ItemSave>();

            for (int i = 0; i < savableItems.Length; i++)
            {
                result.Add(HandleParse(savableItems[i]));
            }

            return result.ToArray();
        }

        private ItemSave HandleParse(SavableItem savableItem)
        {
            return new ItemSave(savableItem.Item, savableItem.gameObject.transform.position, savableItem.gameObject.transform.rotation.eulerAngles, savableItem.gameObject.transform.localScale);
        }
#endif
    }
}
