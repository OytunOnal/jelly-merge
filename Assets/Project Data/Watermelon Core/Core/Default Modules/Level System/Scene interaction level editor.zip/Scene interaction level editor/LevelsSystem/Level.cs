﻿#pragma warning disable 649

using UnityEngine;

namespace Watermelon
{
    public class Level : ScriptableObject
    {
        [SerializeField] ItemSave[] items;

        public ItemSave[] Items
        {
            get => items;
        }

        public int ItemsAmount
        {
            get => items.Length;
        }
    }
}