﻿#pragma warning disable 0414, 0649

using UnityEngine;

namespace Watermelon
{
    public class LevelsDatabase : ScriptableObject, IInitialized
    {
        private static LevelsDatabase instance;

        [SerializeField] private Level[] levels;

        public static int LevelsCount
        {
            get { return instance.levels.Length; }
        }

        public void Init()
        {
            instance = this;
        }

        public static Level GetLevel(int index)
        {
            index = Mathf.Clamp(index - 1, 0, instance.levels.Length - 1);
            return instance.levels[index];
        }
    }
}