﻿#pragma warning disable 0414,649

using UnityEngine;

namespace Watermelon
{
    [System.Serializable]
    public class Level : ScriptableObject
    {
        public Vector2Int size;

        public IntArray[] items;
        public IntArray[] extraProps;

        [System.Serializable]
        public struct IntArray
        {
            public int[] ints;

            public IntArray(int[] list)
            {
                ints = list;
            }
        }
    }
}